#include "defs.h"
int main(){}
