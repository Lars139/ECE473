#include "defs.h"
#include "buffer.h"
int insert_function(){}
