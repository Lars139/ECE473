#include "defs.h" 
#include "command.h"
int kbd_function(){}
